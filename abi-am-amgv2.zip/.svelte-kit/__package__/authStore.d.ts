import type { User } from "firebase/auth";
export declare const user: import("svelte/store").Writable<User | null>;
