import { writable } from "svelte/store";
import { auth } from "./firebase.js";
export const user = writable(null);
auth.onAuthStateChanged((firebaseUser) => {
    user.set(firebaseUser);
});
