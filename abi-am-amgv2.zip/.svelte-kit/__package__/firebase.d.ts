export declare const auth: import("@firebase/auth").Auth;
export declare const db: import("@firebase/firestore").Firestore;
export declare function registerUser(email: string, password: string): Promise<import("@firebase/auth").User>;
export declare function loginUser(email: string, password: string): Promise<import("@firebase/auth").User>;
export declare function logoutUser(): Promise<void>;
export declare function saveVote(userId: string, votes: {
    name: string;
    value: number;
}[]): Promise<void>;
export declare function getVotes(userId: string): Promise<import("@firebase/firestore").DocumentData | null>;
