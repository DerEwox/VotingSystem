import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, sendEmailVerification } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc } from "firebase/firestore";
const firebaseConfig = {
    apiKey: "AIzaSyB3kI4PeaDP8KoSdW4IkaNuREaak60qvF4",
    authDomain: "abiamamg.firebaseapp.com",
    projectId: "abiamamg",
    storageBucket: "abiamamg.firebasestorage.app",
    messagingSenderId: "1004836011721",
    appId: "1:1004836011721:web:e5e57a55f8eb52cdf49718",
    measurementId: "G-NQL8DK5ZPD"
};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
// Funktionen für Auth & Votes
export async function registerUser(email, password) {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    await sendEmailVerification(userCredential.user);
    return userCredential.user;
}
export async function loginUser(email, password) {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
}
export async function logoutUser() {
    return signOut(auth);
}
export async function saveVote(userId, votes) {
    const voteRef = doc(db, "votes", userId);
    await setDoc(voteRef, { votes, timestamp: new Date() });
}
export async function getVotes(userId) {
    const voteRef = doc(db, "votes", userId);
    const docSnap = await getDoc(voteRef);
    return docSnap.exists() ? docSnap.data() : null;
}
